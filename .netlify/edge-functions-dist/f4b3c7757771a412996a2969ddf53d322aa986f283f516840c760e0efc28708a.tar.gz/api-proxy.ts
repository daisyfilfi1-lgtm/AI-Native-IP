/// <reference types="@netlify/edge-functions" />

/**
 * Netlify Edge Function - API Proxy
 * 简单的代理：将 /api/* 请求转发到 Railway
 */

const RAILWAY_API = "https://ai-native-ip-production.up.railway.app";

export default async function handler(request: Request): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const search = url.search;

  console.log(`[Edge] ${request.method} ${path}${search}`);

  // CORS 预检
  if (request.method === "OPTIONS") {
    return new Response(null, {
      status: 204,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Requested-With, X-API-Key",
        "Access-Control-Max-Age": "86400",
      },
    });
  }

  // 只处理 /api/* 请求
  if (!path.startsWith("/api/")) {
    return new Response(JSON.stringify({ error: "Not Found" }), {
      status: 404,
      headers: { "Content-Type": "application/json" }
    });
  }

  const targetUrl = `${RAILWAY_API}${path}${search}`;

  // 构建转发请求
  const headers = new Headers();
  request.headers.forEach((value, key) => {
    const lower = key.toLowerCase();
    if (lower !== "host" && lower !== "origin" && lower !== "content-length") {
      headers.set(key, value);
    }
  });

  // 添加代理标识
  headers.set("X-Forwarded-By", "Netlify-Edge");

  try {
    const response = await fetch(targetUrl, {
      method: request.method,
      headers,
      body: request.body,
    });

    console.log(`[Edge] ${path} -> ${response.status}`);

    // 复制响应头，添加 CORS
    const responseHeaders = new Headers();
    response.headers.forEach((value, key) => {
      if (key.toLowerCase() !== "content-encoding") {
        responseHeaders.set(key, value);
      }
    });
    responseHeaders.set("Access-Control-Allow-Origin", "*");

    return new Response(response.body, {
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
    });

  } catch (error) {
    console.error(`[Edge] Error:`, error);

    return new Response(JSON.stringify({
      error: "Proxy error",
      message: error instanceof Error ? error.message : String(error)
    }), {
      status: 502,
      headers: { "Content-Type": "application/json" }
    });
  }
}
